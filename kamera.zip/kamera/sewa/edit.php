<?php
session_start();
include "../koneksi.php";
$kd_sewa=$_GET['kd_sewa'];
$sql="SELECT * FROM sewa WHERE kd_sewa='$kd_sewa'";
$query=mysqli_query($koneksi,$sql);

if(!isset($_SESSION['login'])){
    header("location:../login.php?pesan=login dulu");
}
while($sewa=mysqli_fetch_assoc($query)){

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Edut</h1>

    <form action="p_e.php" method="post">
        <input type="hidden" name="kd_sewa" value="<?=$sewa['kd_sewa'];?>">    

        <label for="">KD KAMERA</label><br>
        <input type="number" name="kd_kamera" id="" value="<?=$sewa['kd_kamera'];?>"><br>
        
        <label for="">KD CUSTOMER</label><br>
        <input type="number" name="kd_customer" id="" value="<?=$sewa['kd_customer'];?>"><br>

        <label for="">TGL PINJAM</label><br>
        <input type="date" name="tgl_pinjam" id="" value="<?=$sewa['tgl_pinjam'];?>"><br>

        <label for="">TGL KEMBALI</label><br>
        <input type="date" name="tgl_kembali" id="" value="<?=$sewa['tgl_kembali'];?>"><br>

        <input type="submit" value="Edit" class="btn btn-info">
        
    </form>
</body>
</html>
<?php
}
?>