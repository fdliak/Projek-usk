<?php
session_start();
include "../koneksi.php";

$sql="SELECT * FROM sewa ";
$query=mysqli_query($koneksi,$sql);

if(!isset($_SESSION['login'])){
    header("location:../login.php?pesan=login dulu");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SeWA</title>
    <link rel="stylesheet" href="../bootstrap.css">
</head>
<body>
    <div class="container">
    <h1 class="text-center">SEWA</h1>
    <a href="tambah.php"><button class="btn btn-success">Tambah</button></a>
    <a href="../logout.php"><button class="btn btn-danger">Logout</button></a>
    <br><br>


    <table class="table table-striped">
        <tr class="table-dark">
            <th>Kd Sewa</th>
            <th>Kd kamera</th>
            <th>Kd customer</th>
            <th>Tgn Pinjam</th>
            <th>Tgl Kembali</th>
            <th>Total Sewa</th>
            <th>Aksi</th>
        </tr>
        <?php
        while($sewa=mysqli_fetch_assoc($query)){
            ?>
            <tr>
                <td><?=$sewa['kd_sewa'];?></td>
                <td><?=$sewa['kd_kamera'];?></td>
                <td><?=$sewa['kd_customer'];?></td>
                <td><?=$sewa['tgl_pinjam'];?></td>
                <td><?=$sewa['tgl_kembali'];?></td>
                <td><?=$sewa['total_sewa'];?></td>
                <td>
                        <a href="edit.php?kd_sewa=<?=$sewa['kd_sewa'];?>"><button class="btn btn-danger">Edit</button></a>
                        <a href="hapus.php?kd_sewa=<?=$sewa['kd_sewa'];?>"><button class="btn btn-warning">Hapus</button></a>
                </td>
            </tr>

        <?php
        }
        ?>
    </table>
    </div>
</body>
</html>