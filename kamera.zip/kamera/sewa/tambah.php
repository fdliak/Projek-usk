<?php
session_start();
include "../koneksi.php";
if(!isset($_SESSION['login'])){
    header("location:../login.php?pesan=login dulu");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Tambah</h1>

    <form action="p_t.php" method="post">
        
        <label for="">KD KAMERA</label><br>\
        <input type="number" name="kd_kamera" id=""><br>
        
        <label for="">KD CUSTOMER</label><br>\
        <input type="number" name="kd_customer" id=""><br>

        <label for="">TGL PINJAM</label><br>
        <input type="date" name="tgl_pinjam" id=""><br>

        <label for="">TGL KEMBALI</label><br>
        <input type="date" name="tgl_kembali" id=""><br>

        <input type="submit" value="Simpan" class="btn btn-info">
        
    </form>
</body>
</html>