<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah</title>
    <link rel="stylesheet" href="../bootstrap.css">

</head>
<div class="container">
<body>
    <h1 class="">Tambah</h1>
    <form action="p_t.php" method="post">
        <label for="">Kd Kamera</label><br>
        <input type="number" name="kd_kamera" id=""><br>

        <label for="">Kd Cutsomer</label><br>
        <input type="number" name="kd_customer" id=""><br>

        <label for="">Tgl Pinjam</label><br>
        <input type="date" name="tgl_pinjam" id=""><br>

        <label for="">Tgl Kembali</label><br>
        <input type="date" name="tgl_kembali" id=""><br><br>

        <input type="submit" value="Simpan" class="btn btn-info"><br>
    </form>
</body>
</div>
</html>