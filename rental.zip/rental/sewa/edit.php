<?php
include "../koneksi.php";
$kd_sewa =$_GET['kd_sewa'];
$sql="SELECT * FROM sewa WHERE kd_sewa='$kd_sewa'";
$query =mysqli_query($koneksi,$sql);

while($sewa=mysqli_fetch_assoc($query)){





?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah</title>
    <link rel="stylesheet" href="../bootstrap.css">

</head>
<div class="container">
<body>
    <h1>Edit</h1>
    <form action="p_e.php" method="post">
        <input type="hidden" name="kd_sewa" value="<?=$sewa['kd_sewa'];?>">

        <label for="">Kd Kamera</label><br>
        <input type="number" name="kd_kamera" id="" value="<?=$sewa['kd_kamera'];?>"><br>

        <label for="">Kd Cutsomer</label><br>
        <input type="number" name="kd_customer" id="" value="<?=$sewa['kd_customer'];?>"><br>

        <label for="">Tgl Pinjam</label><br>
        <input type="date" name="tgl_pinjam" id="" value="<?=$sewa['tgl_pinjam'];?>"><br>

        <label for="">Tgl Kembali</label><br>
        <input type="date" name="tgl_kembali" id="" value="<?=$sewa['tgl_kembali'];?>"><br><br>

        <input type="submit" value="Simpan" class="btn btn-info">
    </form>
</body>
</div>
</html>
<?php
}
?>