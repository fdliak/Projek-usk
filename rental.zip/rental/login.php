<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap.css">k
</head>
<body>
    <div class="text-center d-flex flex-column min-vh-100 justify-content-center align-items-center">
        <div class="card p-5">
            <h1 class="m-4">LOGIN</h1>
            <form action="p_log.php" method="post">
            <input type="text" name="username" id="" placeholder="username"><br><br>

            <input type="password" name="password" placeholder="password"><br><br>

            <input type="submit" value="LOGIN" class="btn btn-info form-control" >
            </form>
        </div>
    </div>
    
</body>
</html>