<?php
$server = "localhost";
$username ="root";
$password ="";
$database = "db_rental1";

$koneksi = mysqli_connect($server,$username,$password,$database);

// if($koneksi){
//     echo "y";
// }else{
//     echo "g";
// }

?>